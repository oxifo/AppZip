package com.luklin.activities;
import androidx.appcompat.app.*;
import java.io.*;

public class jsInterface extends AppCompatActivity
{
	public void DownloadList(){
		String path ="/storage/emulated/0/Android/data/apk.luklin/movie/";
		try{
			File file = new File(path);
			String[] listen = file.list();
			StringBuffer buffer = new StringBuffer();
			for(int i =0;i<listen.length;i++){
				buffer.append("'"+listen[i]+"',"+System.lineSeparator());
			}
			String mkArray ="var data=["+buffer.toString()+"];";
			FileWriter writer = new FileWriter("/storage/emulated/0/Android/data/apk.luklin/data.js");
			writer.write(mkArray);
			writer.flush();
		}catch(Exception e){}
	}
}