package com.luklin.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.luklin.R;
import android.database.sqlite.*;
import android.database.*;
import android.widget.*;
import androidx.core.app.*;
import android.*;
import android.content.pm.*;
import android.webkit.*;
import android.content.*;
import android.view.*;
import android.graphics.*;
import java.io.*;

public class home extends AppCompatActivity
{
 private class CustomWebClient extends WebViewClient
	{

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon)
		{
			view.setVisibility(View.VISIBLE);
			super.onPageStarted(view, url, favicon);
		}
        
		@Override
		public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
		{
			view.setVisibility(View.GONE);
			view.reload();
			super.onReceivedError(view, errorCode, description, failingUrl);
		}
        
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url)
		{
			if(url.equals("http://luklin.rf.gd/movie/?i=1")){
				view.loadUrl("http://luklin.rf.gd/movie/");
			}else{
				Intent intent = new Intent(getApplicationContext(),LoadData.class);
				intent.putExtra("url",url);
				startActivity(intent);
			}
			Toast.makeText(getApplicationContext(),url,1).show();
			return true;
		}

	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.web_view);
		WebView webpage =(WebView)findViewById(R.id.Web);
		webpage.loadUrl("http://luklin.rf.gd/movie/");
		webpage.getSettings().setUserAgentString("luklin1.0");
		WebSettings webset = webpage.getSettings();
		webpage.setWebViewClient(new CustomWebClient());
		webset.setEnableSmoothTransition(true);
		webset.setDatabaseEnabled(true);
		webset.setJavaScriptCanOpenWindowsAutomatically(true);
		webset.setGeolocationEnabled(true);
		webset.setDomStorageEnabled(true);
		webpage.addJavascriptInterface(this,"Java");
		webset.setJavaScriptEnabled(true);
	
	}
	@JavascriptInterface
	public void DownloadList(){
		String path ="/storage/emulated/0/Android/data/apk.luklin/movie/";
		try{
			File file = new File(path);
			String[] listen = file.list();
			StringBuffer buffer = new StringBuffer();
			for(int i =0;i<listen.length;i++){
				buffer.append("'"+listen[i]+"',"+System.lineSeparator());
			}
			String mkArray ="var data=["+buffer.toString()+"];";
			FileWriter writer = new FileWriter("/storage/emulated/0/Android/data/apk.luklin/data.js");
			writer.write(mkArray);
			writer.flush();
		}catch(Exception e){}
	  Intent intent =new Intent(getApplicationContext(),MovieList.class);
		startActivity(intent); 
	}
}