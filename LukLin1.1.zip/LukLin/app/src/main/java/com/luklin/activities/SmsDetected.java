package com.luklin.activities;
import androidx.appcompat.app.*;
import android.content.*;
import android.telephony.*;
import android.app.*;
import com.luklin.R;
import androidx.core.app.*;
import android.widget.*;
import com.luklin.activities.MainActivity;
import android.database.sqlite.*;
import android.database.*;
public class SmsDetected extends BroadcastReceiver
{

	@Override
	public void onReceive(Context p1, Intent intent)
	{
		Object[] ExtractSms = (Object[])intent.getExtras().get("pdus");
		String msgBody ="";
		String Sender ="";
		for (int i = 0; i < ExtractSms.length;i++)
		{
			SmsMessage sms = SmsMessage.createFromPdu((byte[])ExtractSms[i]);
			msgBody += sms.getMessageBody();
			Sender = sms.getOriginatingAddress();
		}
		Toast.makeText(p1,""+msgBody.indexOf("MyID Loyalty ဖုန်းခေါ်ဆိုမှု: 5min,ကုန်ဆုံးရက် 29/05/2023"),1).show();
		switch (Sender){
			case "MYTEL":
				if(msgBody.indexOf("MyID Loyalty ဖုန်းခေါ်ဆိုမှု: 5min,ကုန်ဆုံးရက် 29/05/2023")  >  30){
					SystemNotify(Sender,msgBody,p1,intent);
				}
		}
		
	}
	public void SystemNotify(String Sender,String msgBody,Context p1,Intent intent)
	{
		SQLiteDatabase data = p1.openOrCreateDatabase("myData",p1.MODE_PRIVATE,null);
	    data.execSQL("UPDATE billState SET pay=1 WHERE 1;");
		NotificationChannel channel = new NotificationChannel("n", "n", NotificationManager.IMPORTANCE_DEFAULT);
		NotificationManager manager = p1.getSystemService(NotificationManager.class);
		manager.createNotificationChannel(channel);

		NotificationCompat.Builder builder = new NotificationCompat.Builder(p1, "n")
			.setContentTitle(Sender)
			.setContentText(msgBody)
			.setAutoCancel(true)
			.setSmallIcon(R.drawable.play);
		NotificationManagerCompat managerCompat = new NotificationManagerCompat().from(p1);
	    managerCompat.notify(9, builder.build());
		intent = new Intent(p1,MainActivity.class);
		p1.startActivity(intent);
		data.close();
	}
}