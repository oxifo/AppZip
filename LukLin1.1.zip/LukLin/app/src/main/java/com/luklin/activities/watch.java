package com.luklin.activities;
import androidx.appcompat.app.*;
import android.os.*;
import android.view.*;
import android.content.pm.*;
import com.luklin.R;
import android.webkit.*;
import com.luklin.activities.MainActivity;
import android.content.*;
import java.util.*;
import java.io.*;
import android.widget.*;
public class watch extends AppCompatActivity
{
String fileName="";
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.web_view);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		WebView web = findViewById(R.id.Web);
		WebSettings setin = web.getSettings();
		setin.setJavaScriptEnabled(true);
		setin.setDomStorageEnabled(true);
		web.addJavascriptInterface(this,"Java");
		web.setWebChromeClient(new WebChromeClient());
		web.setWebViewClient(new WebViewClient(){
			public boolean shouldOverrideUrlLoading(WebView v,String url){
				switch(url){
					default:v.loadUrl(url);
					break;
				}

				return true;
			};
		});
		String value = getIntent().getExtras().getString("fileName");
		fileName +=value;
		web.loadUrl("file:///android_asset/splash.html#"+value);
	}
   @JavascriptInterface
   public void WindowFinish(){
	   this.finish();
   }
   @JavascriptInterface
   public void RenameFile(String input){
     String mPath = "/storage/emulated/0/Android/data/apk.luklin/movie/";
     String audio = "/storage/emulated/0/Android/data/apk.luklin/MAudio/";
     
	   File fmovie = new File(mPath+fileName);
	   fmovie.renameTo(new File(mPath+input));
	   
	   File faudio = new File(audio+fileName);
	   faudio.renameTo(new File(audio+input));
	   Toast.makeText(getApplicationContext(),"Success Rename",1).show();
	   jsInterface js = new jsInterface();
	   js.DownloadList();
	   Intent in = new Intent(getApplicationContext(),MovieList.class);
	   startActivity(in);
	   this.finish();
   }
   @JavascriptInterface
   public void onDeleteMovie(){
	   String data1 = "/storage/emulated/0/Android/data/apk.luklin/movie/";
	   String data2 = "/storage/emulated/0/Android/data/apk.luklin/MAudio/";
	   File f1 = new File(data1+fileName);
	   File f2 = new File(data2+fileName);
	   f1.delete();
	   f2.delete();
	   Toast.makeText(getApplicationContext(),"Success Rename",1).show();
	   jsInterface js = new jsInterface();
	   js.DownloadList();
	   Intent in = new Intent(getApplicationContext(),MovieList.class);
	   startActivity(in);
	   this.finish();
   }
}