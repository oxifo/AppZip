package com.luklin.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.luklin.R;
import android.database.sqlite.*;
import android.database.*;
import android.widget.*;
import androidx.core.app.*;
import android.*;
import android.content.pm.*;
import android.webkit.*;
import android.content.*;
import android.view.*;

public class LoadData extends AppCompatActivity
{
	class CustomViewClient extends WebViewClient
	{

		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url)
		{
			Intent intent = new Intent(getApplicationContext(), LoadData.class);
			intent.putExtra("url", url);
			startActivity(intent);
			Toast.makeText(getApplicationContext(),url,1).show();
			return true;
		}

	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
	    Bundle bundle =getIntent().getExtras();
		String url = bundle.getString("url");
		WebView webpage = new WebView(LoadData.this);
		setContentView(webpage);
		webpage.loadUrl(url);
		webpage.getSettings().setUserAgentString("luklin1.0");
		WebSettings webset = webpage.getSettings();
		webpage.setWebViewClient(new CustomViewClient());
		webset.setEnableSmoothTransition(true);
		webset.setDatabaseEnabled(true);
		webset.setJavaScriptCanOpenWindowsAutomatically(true);
		webset.setGeolocationEnabled(true);
		webset.setDomStorageEnabled(true);
		webset.setJavaScriptEnabled(true);
	}
}