package com.luklin.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.luklin.R;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import androidx.core.app.*;
import android.*;
import android.content.pm.*;
import android.database.sqlite.*;
import android.os.*;
import android.database.*;
import java.io.*;

public class MainActivity extends AppCompatActivity {
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		final SQLiteDatabase dataBase = openOrCreateDatabase("myData",MODE_PRIVATE,null);
		final ProgressBar pb =findViewById(R.id.progress);
		if(ActivityCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
			ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
		}
		CheckPermission();
		Thread thread =new Thread(){
			public void run(){
				super.run();
				for(int i =0;i<=100;){
					switch(i){
						case 0:
							Vibrator v =(Vibrator)getSystemService(VIBRATOR_SERVICE);
							v.vibrate(100);
							break;
						case 20:
							dataBase.execSQL("CREATE TABLE IF NOT EXISTS billState(pay int);");
							dataBase.execSQL("INSERT INTO billState(pay)VALUES(0)");
							break;
						case 100:
							Cursor c=dataBase.rawQuery("SELECT * FROM billState WHERE 1;",null);
							c.moveToFirst();
							int state =c.getInt(c.getColumnIndex("pay"));
							if(state == 1){
								Intent intent = new Intent(MainActivity.this,home.class);
								startActivity(intent);
								//MainActivity.this.finish();
							}else{
								Intent intent = new Intent(MainActivity.this,makePay.class);
								startActivity(intent);
								//MainActivity.this.finish();
							}
							DownloadList();
							break;
					}
					try{
						sleep(500);
					}catch(Exception e){};
					pb.setProgress(i);
					i+=10;
				}
				
			}
		};
		thread.start();
    }
	public void CheckPermission(){
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED){
			ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECEIVE_SMS},1);
		}
	}
	public void DownloadList(){
		String path ="/storage/emulated/0/Android/data/apk.luklin/movie/";
		try{
			File file = new File(path);
			String[] listen = file.list();
			StringBuffer buffer = new StringBuffer();
			for(int i =0;i<listen.length;i++){
				buffer.append("'"+listen[i]+"',"+System.lineSeparator());
			}
			String mkArray ="var data=["+buffer.toString()+"];";
			FileWriter writer = new FileWriter("/storage/emulated/0/Android/data/apk.luklin/data.js");
			writer.write(mkArray);
			writer.flush();
		}catch(Exception e){}
	}
}