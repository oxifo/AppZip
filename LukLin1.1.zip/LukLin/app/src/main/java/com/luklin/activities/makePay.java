package com.luklin.activities;
							
							import android.os.Bundle;
							import androidx.appcompat.app.AppCompatActivity;
							import com.luklin.R;
							import android.database.sqlite.*;
							import android.database.*;
							import android.widget.*;
							import android.content.*;
							import android.net.*;
							import android.view.*;
							import java.io.*;
							import android.app.*;
							import android.webkit.*;
							import android.os.*;
							import android.content.res.*;
							import androidx.core.app.*;
							import android.*;
							import android.content.pm.*;
							
							public class makePay extends AppCompatActivity {
							  final String storage ="/storage/emulated/0/";
							  final String mytelPay = "https://www.pay.mytel.com.mm";
							  final String wavePay ="wavepay://action/direction/";
							  String url ="file:///android_asset/wave.png";
							    @Override
							    protected void onCreate(Bundle savedInstanceState) {
							      final Context context =getApplicationContext();
									super.onCreate(savedInstanceState);
							        setContentView(R.layout.make_pay);
									GridLayout mytel =findViewById(R.id.mytel);
									GridLayout kbz = findViewById(R.id.kbz);
							        GridLayout wave = findViewById(R.id.wave);
									wave.setOnClickListener(new View.OnClickListener(){
										public void onClick(View v){
											ClickOnAgent("https://raw.githubusercontent.com/oxifo/io/main/wavePay.png","image/x-png",wavePay);
											
										}
									});
									mytel.setOnClickListener(new View.OnClickListener(){
											public void onClick(View v){
									    	ClickOnAgent("https://raw.githubusercontent.com/oxifo/io/main/mytelPay.png","image/x-png",mytelPay);
											}
										});
									kbz.setOnClickListener(new View.OnClickListener(){
											public void onClick(View v){
												
											}
										});
										CheckPermission();
									}
							  public void ClickOnAgent(String urlx,String mimitype,String agent){
								  DownloadManager.Request request = new DownloadManager.Request(Uri.parse(urlx));
								  String cookie =CookieManager.getInstance().getCookie(urlx);
								  request.setMimeType(mimitype);
								  request.allowScanningByMediaScanner();
								  request.setTitle("Download QRCODE");
								  request.addRequestHeader("cookie",cookie);
								  request.addRequestHeader("User-Agent","");
								  request.setDestinationInExternalPublicDir("Movie/Luklin/",URLUtil.guessFileName(urlx,"",mimitype));
								  request.setNotificationVisibility(request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
								  DownloadManager dl =(DownloadManager) getSystemService(DOWNLOAD_SERVICE);
								  dl.enqueue(request);
								  Toast.makeText(getApplicationContext(),"QR CODE ကို Download ရယူနေပါသည်",12).show();
								  Intent intent =new Intent(Intent.ACTION_VIEW,Uri.parse(agent));
								  startActivity(intent);
							  }
							  
								public void CheckPermission(){
				
									if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED){
											ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECEIVE_SMS},1);
									}
								
								
								}
						}