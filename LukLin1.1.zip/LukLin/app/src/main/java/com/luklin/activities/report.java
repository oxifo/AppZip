package com.luklin.activities;
import androidx.appcompat.app.*;
import android.os.*;
import android.webkit.*;
import android.content.*;
import java.util.*;
import android.database.sqlite.*;
import android.database.*;

public class report extends AppCompatActivity
{
Context c;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		WebView web = new WebView(report.this);
		setContentView(web);
		Bundle b =getIntent().getExtras();
		String desc =b.getString("desc").toString();
		SQLiteDatabase db = openOrCreateDatabase("luklin",MODE_PRIVATE,null);
		Cursor c = db.rawQuery("SELECT * FROM Url",null);
		c.moveToFirst();
		String url =c.getString(c.getColumnIndex("url"));
		web.loadUrl("http://luklin.rf.gd/report/?url="+url+"&desc="+desc);
		Timer wait = new Timer();
		wait.schedule(new TimerTask(){
			public void run(){
				report.this.finish();
			}
		},3000);
		
	}
	
}