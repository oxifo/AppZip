package com.luklin.activities;
import androidx.appcompat.app.*;
import android.os.*;
import android.webkit.*;

public class core extends AppCompatActivity
{
  String UserAgent = "";
	@Override
	public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState)
	{
		WebView web = new WebView(this);
		setContentView(web);
		Bundle b =getIntent().getExtras();
		String url = b.getString("url");
		web.loadUrl(url);
		WebSettings setAs = web.getSettings();
		setAs.setJavaScriptEnabled(true);
		setAs.setUserAgentString(UserAgent);
		setAs.setDomStorageEnabled(true);
		super.onCreate(savedInstanceState, persistentState);
	}
	
}